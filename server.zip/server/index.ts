import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
});

let currentStatus: 'waiting' | 'active' | 'ended' = 'waiting';
let votes = { A: 0, B: 0 };

io.on('connection', (socket) => {
  console.log('🔌 New user connected:', socket.id);

  socket.on('joinGauntletRoom', () => {
    console.log('🛡️ Joined Gauntlet Room');
    socket.join('gauntlet');
    socket.emit('gauntletStatus', currentStatus);
  });

  socket.on('startGauntlet', () => {
    currentStatus = 'active';
    votes = { A: 0, B: 0 };
    io.to('gauntlet').emit('gauntletStatus', 'active');
    console.log('🔥 Gauntlet started!');
  });

  socket.on('endGauntlet', () => {
    currentStatus = 'ended';
    io.to('gauntlet').emit('gauntletStatus', 'ended');
    console.log('🛑 Gauntlet ended!');
  });

  socket.on('audienceVote', ({ choice }: { choice: 'A' | 'B' }) => {
    if (choice === 'A' || choice === 'B') {
      votes[choice]++;
      console.log(`📣 Vote for ${choice}: ${votes[choice]} total`);
    }
  });

  socket.on('disconnect', () => {
    console.log('❌ User disconnected:', socket.id);
  });
});

const PORT = 3001;
server.listen(PORT, () => {
  console.log(`🚀 Socket.IO server running on http://localhost:${PORT}`);
});
